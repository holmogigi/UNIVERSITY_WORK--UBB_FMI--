package org.example.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.ListOfWebElementFacades;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;


import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@DefaultUrl("https://www.emag.ro/")
public class EmagPage extends PageObject {

    @FindBy(name = "query")
    private WebElementFacade searchTerms;

    @FindBy(className = "btn btn-default searchbox-submit-button")
    private WebElementFacade lookupButton;

    public void enter_keywords(String keyword) {
        searchTerms.type(keyword);
    }

    public void lookup_terms() {
        // lookupButton.click();
        searchTerms.sendKeys(Keys.ENTER);
    }

    public List<String> get_products(String productName) {
        WebElementFacade resultList = find(By.id("card_grid"));
        return resultList.findElements(By.className("card-v2-title-wrapper")).stream()
                .map(element -> element.findElement(By.tagName("a")))
                .map(element -> element.getText())
                .collect(Collectors.toList());
    }

    public String getInvalidSearchMessage(String productName) {
        WebElementFacade result = find(By.cssSelector(".clearfix.pad-btm-md"));
        WebElement titleElement = result.findElement(By.cssSelector(".listing-grid-title.js-head-title.pad-btm-xs.h4 .title-phrasing.title-phrasing-sm.text-danger"));
        return titleElement.getText();
    }

    public List<String> filter_results(String filter) {
        WebElementFacade noutatiButton = find(By.xpath("//a[contains(@class, 'js-filter-item') and contains(text(), 'Noutati')]"));

        if (noutatiButton != null && noutatiButton.isDisplayed() && noutatiButton.isEnabled()) {
            // Click the "Noutati" button
            noutatiButton.click();

            // Wait for the result list to be visible and interactable
            waitForCondition().until(driver -> find(By.id("card_grid")).isVisible());

            // Retrieve the list of products
            WebElementFacade resultList = find(By.id("card_grid"));
            ListOfWebElementFacades productElements = resultList.thenFindAll(By.className("card-v2-info"));

            // Retrieve the list of product names
            return productElements.stream()
                    .map(element -> {
                        try {
                            WebElement productTitle = element.findElement(By.cssSelector(".card-v2-title-wrapper a.card-v2-title"));
                            return productTitle.getText();
                        } catch (org.openqa.selenium.StaleElementReferenceException e) {
                            // Re-fetch the element if it becomes stale
                            WebElement refreshedElement = element.findElement(By.cssSelector(".card-v2-title-wrapper a.card-v2-title"));
                            return refreshedElement.getText();
                        }
                    })
                    .collect(Collectors.toList());
        } else {
            return Collections.emptyList();
        }
    }
}