package org.example.steps.serenity;

import net.thucydides.core.annotations.Step;
import org.example.pages.DictionaryPage;
import org.example.pages.EmagPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasItem;

public class EmagEndUserSteps {

    EmagPage emagPage;

    @Step
    public void is_the_home_page() {
        emagPage.open();
    }

//    @Step
//    public void filter_products(String filter) {
//        assert emagPage.filter_results(filter);
//    }

    @Step
    public void should_see_products(String productName) {
        assert !emagPage.get_products(productName).isEmpty();
    }

    @Step
    public void should_see_invalid_search_message(String productName) {
        assertThat(emagPage.getInvalidSearchMessage(productName), containsString("0 rezultate pentru:"));
    }

    @Step
    public void enters(String keyword) {
        emagPage.enter_keywords(keyword);
    }

    @Step
    public void starts_search() {
        emagPage.lookup_terms();
    }

    @Step
    public void looks_for(String term) {
        enters(term);
        starts_search();
    }

    @Step
    public void filter_products(String filter) {
        assert !emagPage.filter_results(filter).isEmpty();
    }
}