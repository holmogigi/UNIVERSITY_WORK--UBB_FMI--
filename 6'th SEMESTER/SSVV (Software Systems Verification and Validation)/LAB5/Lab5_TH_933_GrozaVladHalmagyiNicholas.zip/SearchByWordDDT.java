package org.example.features.search;


import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Issue;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.Qualifier;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.EmagEndUserSteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/InvalidTestData.csv")
public class SearchByWordDDT {
    @Managed(uniqueSession = true)
    public WebDriver webdriver;


    @Steps
    public EmagEndUserSteps endUser;

    public String word;
    public String product;
    public String filter;

    @Qualifier
    public String getQualifier() {
        return word;
    }


    @Issue("#EMAG-2")
    @Test
    public void searchByProductTestInvalidDDT() {

        endUser.is_the_home_page();
        endUser.looks_for(getWord());
        endUser.should_see_invalid_search_message(getProduct());
    }

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }
}
